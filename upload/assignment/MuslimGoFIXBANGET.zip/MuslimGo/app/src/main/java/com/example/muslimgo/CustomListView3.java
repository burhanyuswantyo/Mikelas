package com.example.muslimgo;


import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.muslimgo.R;

import java.io.InputStream;


public class CustomListView3 extends ArrayAdapter<String > {

    private String[] deskripsi;
    private String[] menu_id;
    private String[] image;
    private Activity context;
    Bitmap bitmap;

    public CustomListView3(Activity context,String[] deskripsi,String[] menu_id,String[] image) {
        super(context, R.layout.layout2,deskripsi);
        this.context=context;
        this.deskripsi=deskripsi;
        this.menu_id=menu_id;
        this.image=image;
}

    @NonNull
    @Override

    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        View r=convertView;
        com.example.muslimgo.CustomListView.ViewHolder viewHolder=null;
        if(r==null){
            LayoutInflater layoutInflater=context.getLayoutInflater();
            r=layoutInflater.inflate(R.layout.layout2,null,true);
            viewHolder=new com.example.muslimgo.CustomListView.ViewHolder(r);
            r.setTag(viewHolder);
        }
        else {
            viewHolder=(com.example.muslimgo.CustomListView.ViewHolder)r.getTag();

        }

        viewHolder.tvw1.setText(deskripsi[position]);
        viewHolder.tvw2.setText(menu_id[position]);
        new com.example.muslimgo.CustomListView.GetImageFromURL(viewHolder.ivw).execute(image[position]);

        return r;
    }

    class ViewHolder{

        TextView tvw1;
        TextView tvw2;
        ImageView ivw;

        ViewHolder(View v){
            tvw1=(TextView)v.findViewById(R.id.tvprofilename);
            tvw2=(TextView)v.findViewById(R.id.tvemail);
            ivw=(ImageView)v.findViewById(R.id.imageView);
        }

    }

    public class GetImageFromURL extends AsyncTask<String,Void,Bitmap>
    {

        ImageView imgView;
        public GetImageFromURL(ImageView imgv)
        {
            this.imgView=imgv;
        }
        @Override
        protected Bitmap doInBackground(String... url) {
            String urldisplay=url[0];
            bitmap=null;

            try{

                InputStream ist=new java.net.URL(urldisplay).openStream();
                bitmap= BitmapFactory.decodeStream(ist);
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
            }

            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap){

            super.onPostExecute(bitmap);
            imgView.setImageBitmap(bitmap);
        }
    }



}
