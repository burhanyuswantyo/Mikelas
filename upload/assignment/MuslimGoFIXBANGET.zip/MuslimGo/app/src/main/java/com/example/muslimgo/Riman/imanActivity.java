package com.example.muslimgo.Riman;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.muslimgo.CustomListView;
import com.example.muslimgo.R;
import com.example.muslimgo.Tsholat.CustomListView2;

import android.os.StrictMode;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class imanActivity extends AppCompatActivity {

    String urladdress="http://192.168.1.68/muslimgo/materi3.php";
    String[] deskripsi;
    String[] menu_id;
    String[] image;
    ListView listView;
    BufferedInputStream is;
    String line=null;
    String result=null;
    private ListAdapter customListView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iman);
        listView=(ListView)findViewById(R.id.lview);

        StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder().permitNetwork().build()));
        collectData();
        CustomListView2 customListView2=new CustomListView2(this,deskripsi,menu_id,image);
        listView.setAdapter(customListView2);
    }

    private void collectData()
    {
//Connection
        try{

            URL url=new URL(urladdress);
            HttpURLConnection con=(HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            is=new BufferedInputStream(con.getInputStream());

        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        //content
        try{
            BufferedReader br=new BufferedReader(new InputStreamReader(is));
            StringBuilder sb=new StringBuilder();
            while ((line=br.readLine())!=null){
                sb.append(line+"\n");
            }
            is.close();
            result=sb.toString();

        }
        catch (Exception ex)
        {
            ex.printStackTrace();

        }

//JSON
        try{
            JSONArray ja=new JSONArray(result);
            JSONObject jo=null;
            deskripsi=new String[ja.length()];
            menu_id=new String[ja.length()];
            image=new String[ja.length()];

            for(int i=0;i<=ja.length();i++){
                jo=ja.getJSONObject(i);
                deskripsi[i]=jo.getString("deskripsi");
                menu_id[i]=jo.getString("menu_id");
                image[i]=jo.getString("image");
            }
        }
        catch (Exception ex)
        {

            ex.printStackTrace();
        }


    }
    public boolean onSupportNavigateUp (){
        finish();
        return true;
    }

}
