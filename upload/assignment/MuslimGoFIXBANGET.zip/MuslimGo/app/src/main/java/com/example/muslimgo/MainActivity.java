package com.example.muslimgo;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.view.View;

import android.os.Bundle;

import com.example.muslimgo.Hijayah.hijayahActivity;
import com.example.muslimgo.Rislam.islamActivity;
import com.example.muslimgo.Riman.imanActivity;
import com.example.muslimgo.Tsholat.sholatActivity;
import com.example.muslimgo.About.aboutActivity;

public class MainActivity extends AppCompatActivity {

    ImageButton img_hijayah,img_rislam,img_riman,img_tsholat,img_about;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);


        img_hijayah = (ImageButton) findViewById(R.id.img_hijayah);
        img_rislam = (ImageButton) findViewById(R.id.img_rislam);
        img_riman = (ImageButton) findViewById(R.id.img_riman);
        img_tsholat = (ImageButton) findViewById(R.id.img_tsholat);
        img_about = (ImageButton) findViewById(R.id.img_about);


        img_hijayah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent img_hijayah = new Intent(MainActivity.this, hijayahActivity.class);
                startActivity(img_hijayah);
            }
        });

        img_rislam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent img_rislam = new Intent(MainActivity.this, islamActivity.class);
                startActivity(img_rislam);
            }
        });

        img_riman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent img_riman = new Intent(MainActivity.this, imanActivity.class);
                startActivity(img_riman);
            }
        });

        img_tsholat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent img_tsholat = new Intent(MainActivity.this, sholatActivity.class);
                startActivity(img_tsholat);
            }
        });

        img_about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent img_about = new Intent(MainActivity.this, aboutActivity.class);
                startActivity(img_about);
            }
        });
    }
    public boolean onSupportNavigationUp(){
        finish();
        return true;
    }
}
